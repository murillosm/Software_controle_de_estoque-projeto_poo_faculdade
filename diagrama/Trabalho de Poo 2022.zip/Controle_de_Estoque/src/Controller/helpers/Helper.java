package Controller.helpers;

public interface Helper {
	public abstract Object obterModelo();
	public abstract void limparTela();
}
